<?php
 $conn = mysqli_connect("localhost","root","","assiment");
 mysqli_query($conn,"SET NAME '.utf8.'");
?>