<?php
//Khai bao cac bien
$server="localhost"; $u="id20969204_tungnxph18782"; $p="Tung261003@"; $db="id20969204_mob403";
//tao ket noi voi CSDL
$con=new mysqli($server,$u,$p,$db);
//kiem tra ket noi, neu co loi thi thong bao
if($con->connect_error){
     die("Loi ket noi: ".$con->connect_error);
}
//chuoi insert
$sql="DELETE from MyGuests WHERE id=163";
//thuc hien insert
if($con->query($sql)===TRUE){
     echo "Delet thanh cong";
}
else{
     echo "Loi: ".$con->error;
}
?>