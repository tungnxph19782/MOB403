package com.hnq40.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.hnq40.myapplication.R;

import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Demo41MainActivity extends AppCompatActivity {
    EditText txt1,txt2,txt3;
    Button btn1,btn2;
    TextView tvKQ;


    @SuppressLint("MissingInflatedID")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_main);
        txt1 = findViewById(R.id.demo41txt1);
        txt2 = findViewById(R.id.demo41txt2);
        txt3 = findViewById(R.id.demo41txt3);
        btn1 = findViewById(R.id.demo4btn1);
        btn2 = findViewById(R.id.demo41btn2);
        tvKQ = findViewById(R.id.demo41Tvkq);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectData();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertData();
            }
        });


    }
    String kq = "";// chuoi ketqua
    ArrayList<Prd> ls = new ArrayList<>(); //tao list prd
    Prd prd = new Prd();// tao doi tuong trong prd
    void insertData(){
        // dua du lieu vao doi tuong
        prd.setName(txt1.getText().toString());
        prd.setPrice(txt2.getText().toString());
        prd.setDescription(txt3.getText().toString());
        //B1 : Tao doi tuong retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab4/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //B2 : Chuan bi ham va thuc thi
        //B2.1 : goi interface
        InterfaceInsert interfaceInsert = retrofit.create(InterfaceInsert.class);
        // 2.2 chuan bi ham
        Call<SvrResponseInsert> call = interfaceInsert.insertPrd(prd.getName(), prd.getPrice(), prd.getDescription());
        //2.3 goi ham
        call.enqueue(new Callback<SvrResponseInsert>() {
            // thanh cong
            @Override
            public void onResponse(Call<SvrResponseInsert> call, Response<SvrResponseInsert> response) {
                SvrResponseInsert svrResponseInsert = response.body();// lay  dung server tra ve
                tvKQ.setText(svrResponseInsert.getMessage()); // in ra ket qua

            }
            // that bai
            @Override
            public void onFailure(Call<SvrResponseInsert> call, Throwable t) {

            }
        });



    }
    void selectData(){
        //b1 : tao doi tuong retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab4/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        // b2 : goi interface , chuan bi ham goi ham
        InterfaceSelect interfaceSelect = retrofit.create(InterfaceSelect.class);
        Call<SvrResponseSelect> call = interfaceSelect.getPrd();
        call.enqueue(new Callback<SvrResponseSelect>() {
            @Override
            public void onResponse(Call<SvrResponseSelect> call, Response<SvrResponseSelect> response) {
                SvrResponseSelect svrResponseSelect = response.body();
                ls = new ArrayList<>(Arrays.asList(svrResponseSelect.getProducts()));
                for(Prd p: ls)//cho vao vong for de doc tung doi tuong
                {
                    kq +="Name: "+p.getName()+
                            "; Price: "+p.getPrice()+
                            "; Des: "+p.getDescription()+"\n";
                }
                tvKQ.setText(kq);
            }

            @Override
            public void onFailure(Call<SvrResponseSelect> call, Throwable t) {

            }
        });
    }
}