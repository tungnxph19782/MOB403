package com.hnq40.myapplication.demo4;

public class SvrResponseInsert { // GET
    private Prd products; // khong viet sai ten bang
    private String message;

    public Prd getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
