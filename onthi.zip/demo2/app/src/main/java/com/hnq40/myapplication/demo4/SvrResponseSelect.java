package com.hnq40.myapplication.demo4;

public class SvrResponseSelect {
    private Prd[] products;

    public Prd[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }

    private String message;


}
