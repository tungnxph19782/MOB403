package com.hnq40.myapplication.Ph19782onthi;

import static com.hnq40.myapplication.R.*;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.hnq40.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ph19782MainActivity extends AppCompatActivity {
    TextView ph19782tvKQ;
    Button ph19782btn1,ph19782btn2;
    Context context = this;
    String kq = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_ph19782_main);
        ph19782tvKQ = findViewById(id.ph19782tvKQ);
        ph19782btn1 = findViewById(id.ph19782btn1);
        ph19782btn2 = findViewById(id.ph19782btn2);

        ph19782btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ph19782selectdata();
            }
        });
        ph19782btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ph19782selectsach();
            }
        });
    }
    private void ph19782selectdata(){
        RequestQueue queue = Volley.newRequestQueue(context);
        String url = "https://batdongsanabc.000webhostapp.com/mob403lab4/getall.json";
        JsonObjectRequest request = new JsonObjectRequest(url, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray products = response.getJSONArray("products");
                    kq = "";

                    for (int i = 0 ; i < products.length() ; i++){
                        JSONObject prodcut = products.getJSONObject(i);
                            String pid = prodcut.getString("pid");
                            String name = prodcut.getString("name");
                            String price = prodcut.getString("price");
                            kq += "pid :"+ pid + "\n";
                            kq += "name :"+ name + "\n";
                            kq += "price :"+price + "\n";
                    }
                    ph19782tvKQ.setText(kq);
                } catch (JSONException e){
                        e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                ph19782tvKQ.setText((CharSequence) error.getMessage());
            }
        });
            queue.add(request);
    }
    private void ph19782selectsach(){
        RequestQueue queue = Volley.newRequestQueue(context);
        String url = "http://192.168.51.103/onthimob403/getdata1.php";
        JsonObjectRequest request = new JsonObjectRequest(url, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray products = response.getJSONArray("");
                    kq = "";

                    for (int i = 0 ; i < products.length() ; i++){
                        JSONObject prodcut = products.getJSONObject(i);
                        String MASH = prodcut.getString("MASH");
                        String TENSACH = prodcut.getString("TENSACH");
                        String TACGIA = prodcut.getString("TACGIA");
                        kq += "pid :"+ MASH + "\n";
                        kq += "name :"+ TENSACH + "\n";
                        kq += "price :"+TACGIA + "\n";
                    }
                    ph19782tvKQ.setText(kq);
                } catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                ph19782tvKQ.setText((CharSequence) error.getMessage());
            }
        });
        queue.add(request);
    }
}